package general;

/**
 * Represents all types of treasures.
 */
public enum Treasure {
  DIAMOND, RUBY, SAPPHIRE;
}
